<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin" atau "Dokter"
if (!isset($_SESSION['username']) || ($_SESSION['role'] !== 'Admin' && $_SESSION['role'] !== 'Dokter')) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses form saat disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pasien = $_POST['id_pasien'];
    $id_dokter = $_POST['id_dokter'];
    $tanggal_kunjungan = $_POST['tanggal_kunjungan'];
    $diagnosa = $_POST['diagnosa'];
    $tindakan = $_POST['tindakan'];
    $resep_obat = $_POST['resep_obat'];
    $catatan = $_POST['catatan'];
    $alergi = $_POST['alergi'];

    // Validasi input agar tidak ada field yang kosong
    if (empty($id_pasien) || empty($id_dokter) || empty($tanggal_kunjungan) || empty($diagnosa) || empty($tindakan) || empty($resep_obat) || empty($catatan) || empty($alergi)) {
        echo "Semua field harus diisi.";
    } else {
        // Periksa apakah koneksi database valid
        if ($conn) {
            // Gunakan prepared statements untuk menghindari SQL Injection
            $stmt = $conn->prepare("INSERT INTO rekam_medis (id_pasien, id_dokter, tanggal_kunjungan, diagnosa, tindakan, resep_obat, catatan, alergi) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            
            // Cek apakah prepare berhasil
            if ($stmt === false) {
                die("Error preparing statement: " . $conn->error);
            }
            
            // Bind parameter dengan tipe data sesuai: i = integer, s = string
            $stmt->bind_param("iissssss", $id_pasien, $id_dokter, $tanggal_kunjungan, $diagnosa, $tindakan, $resep_obat, $catatan, $alergi);

            // Eksekusi statement
            if ($stmt->execute()) {
                // Redirect jika berhasil
                header("Location: kelola_rekam_medis.php");
                exit();
            } else {
                // Tampilkan error jika eksekusi gagal
                echo "Error: " . $stmt->error;
            }

            // Tutup statement
            $stmt->close();
        } else {
            // Tampilkan error jika koneksi database gagal
            die("Koneksi database gagal");
        }
    }
}

// Tutup koneksi
$conn->close();
?>
