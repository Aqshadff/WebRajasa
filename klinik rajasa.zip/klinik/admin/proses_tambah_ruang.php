<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Ambil data dari form
$nama_ruang = $_POST['nama_ruang'];
$lokasi = $_POST['lokasi'];
$kapasitas = $_POST['kapasitas'];
$status = $_POST['status'];

// Validasi data
if (empty($nama_ruang) || empty($lokasi) || empty($kapasitas) || empty($status)) {
    echo "Semua field harus diisi.";
    exit();
}

// Masukkan data ke database
$sql = "INSERT INTO ruang (nama_ruang, lokasi, kapasitas, status) 
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $nama_ruang, $lokasi, $kapasitas, $status);

if ($stmt->execute()) {
    // Redirect setelah berhasil
    header("Location: kelola_ruang.php");
    exit();
} else {
    echo "Terjadi kesalahan: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>