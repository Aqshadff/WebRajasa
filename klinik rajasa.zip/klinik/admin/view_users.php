<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db"; 

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Tidak dapat terhubung ke database: " . $e->getMessage());
}

// Query untuk mengambil data pasien
$query = "SELECT * FROM pasien";
$stmt = $pdo->prepare($query);
$stmt->execute();
$pasien = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pasien</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item active">
                    <a href="kelola_pasien.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Daftar Pasien</h2>
                <a href="tambah_pasien.php" class="btn btn-primary add-patient-btn">Tambah Pasien</a>
            </header>
            <div class="app-content-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Pasien</th>
                            <th>Alamat</th>
                            <th>Tanggal Lahir</th>
                            <th>No. Telepon</th>
                            <th>Jenis Kelamin</th>
                            <th>Gol Darah</th>
                            <th>Jenis Pembayaran</th>
                            <th>Tanggal Registrasi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                         $no = 1; // Memulai nomor urut dari 1
                        foreach ($pasien as $p): ?>
                            <tr>
                                <td><?php echo $no++; // Menampilkan nomor urut ?></td>
                                <td><?php echo htmlspecialchars($p['nama_pasien']); ?></td>
                                <td><?php echo htmlspecialchars($p['alamat']); ?></td>
                                <td><?php echo htmlspecialchars($p['tanggal_lahir']); ?></td>
                                <td><?php echo htmlspecialchars($p['nomor_telepon']); ?></td>
                                <td><?php echo htmlspecialchars($p['jenis_kelamin']); ?></td>
                                <td><?php echo htmlspecialchars($p['golongan_darah']); ?></td>
                                <td><?php echo htmlspecialchars($p['jenis_pembayaran']); ?></td>
                                <td><?php echo htmlspecialchars($p['tanggal_register']); ?></td>
                                <td>
                                    <a href="edit_pasien.php?id=<?php echo htmlspecialchars($p['id_pasien']); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="delete_pasien.php?id_pasien=<?php echo htmlspecialchars($p['id_pasien']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus pasien ini?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- JavaScript for Bootstrap -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
