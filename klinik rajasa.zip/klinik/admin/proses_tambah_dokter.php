<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Ambil data dari form
$nama_dokter = $_POST['nama_dokter'];
$spesialisasi = $_POST['spesialisasi'];
$nomor_telepon = $_POST['nomor_telepon'];
$email = $_POST['email'];
$jadwal_praktik = $_POST['jadwal_praktik'];

// Validasi data
if (empty($nama_dokter) || empty($spesialisasi) || empty($nomor_telepon) || empty($email) || empty($jadwal_praktik)) {
    echo "Semua field harus diisi.";
    exit();
}

// Masukkan data ke database
$sql = "INSERT INTO dokter (nama_dokter, spesialisasi, nomor_telepon, email, jadwal_praktik) 
        VALUES (?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $nama_dokter, $spesialisasi, $nomor_telepon, $email, $jadwal_praktik);

if ($stmt->execute()) {
    // Redirect setelah berhasil
    header("Location: kelola_dokter.php");
    exit();
} else {
    echo "Terjadi kesalahan: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>