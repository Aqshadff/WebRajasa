<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $id_ruang = $_GET['delete_id'];

    $sql = "DELETE FROM ruang WHERE id_ruang = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_ruang);

    if ($stmt->execute()) {
        header("Location: kelola_ruang.php?status=sukses");
        exit();
    } else {
        echo "Terjadi kesalahan: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch records
$sql = "SELECT * FROM ruang";
$result = $conn->query($sql);

if (!$result) {
    echo "Query Error: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Ruang</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item active">
                    <a href="kelola_ruang.php">Kelola Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Kelola Ruang</h2>
                <a href="tambah_ruang.php" class="btn btn-primary">Tambah Ruang</a>
            </header>
            <div class="app-content-body">
                <form method="POST" action="export_ruang.php">
                    <button type="submit" class="btn btn-secondary">CSV</button>
                </form>
                <form method="GET" action="">
                    <div class="mb-3">
                        <input type="text" class="form-control" name="search" placeholder="Cari ruang"
                               value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Cari</button>
                </form>

                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID Ruang</th>
                            <th>Nama Ruang</th>
                            <th>Lokasi</th>
                            <th>Kapasitas</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id_ruang']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_ruang']); ?></td>
                                <td><?php echo htmlspecialchars($row['lokasi']); ?></td>
                                <td><?php echo htmlspecialchars($row['kapasitas']); ?></td>
                                <td><?php echo htmlspecialchars($row['status']); ?></td>
                                <td>
                                    <a href="edit_ruang.php?id_ruang=<?php echo htmlspecialchars($row['id_ruang']); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="kelola_ruang.php?delete_id=<?php echo htmlspecialchars($row['id_ruang']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus ruang ini?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        <?php
                        // Search functionality
                        $search = $_GET['search'] ?? '';
                        if (!empty($search)) {
                            $sql = "SELECT * FROM ruang WHERE nama_ruang LIKE ? OR lokasi LIKE ?";
                            $stmt = $conn->prepare($sql);
                            $search_param = '%' . $search . '%';
                            $stmt->bind_param("ss", $search_param, $search_param);
                            $stmt->execute();
                            $result = $stmt->get_result();
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- JavaScript for Bootstrap -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
