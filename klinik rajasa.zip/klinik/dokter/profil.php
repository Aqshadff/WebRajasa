<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data profil admin dari tabel pengguna
$username = $_SESSION['username'];
$sql = "SELECT * FROM dokter WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nama_dokter = $row['nama_dokter']; // Sesuaikan dengan kolom yang Anda miliki
    $spesialisasi = $row['spesialisasi']; // Sesuaikan dengan kolom yang Anda miliki
    $nomor_telepon = $row['nomor_telepon']; // Sesuaikan dengan kolom yang Anda miliki
    $jadwal_praktik = $row['jadwal_praktik']; // Sesuaikan dengan kolom yang Anda miliki
    $email = $row['email'];
} else {
    echo "Data tidak ditemukan.";
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Dokter - Dokter Panel</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
        }

        .app-container {
            display: flex;
            flex-direction: row;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            position: fixed;
            height: 100%;
            overflow-y: auto;
        }

        .sidebar-header h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }

        .sidebar-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-item {
            margin-bottom: 10px;
        }

        .sidebar-item a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar-item a:hover {
            background: #f0f0f0;
        }

        .app-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            overflow-y: auto;
        }

        .app-content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .app-content-body {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .form-container {
            background: #f9f9f9;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            margin-bottom: 20px;
        }

        .form-container .form-label {
            font-weight: bold;
        }

        .btn-update {
            background-color: #3a1c71;
            color: #fff;
            border: none;
        }

        .btn-update:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            .app-container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                max-width: none;
                position: static;
                box-shadow: none;
            }

            .app-content {
                margin-left: 0;
                margin-top: 20px;
            }
        }
    </style>
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Dokter Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard_dokter.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="data_rekam_medis.php">Data Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="jadwal_kunjungan.php">Jadwal Kunjungan</a>
                </li>
                <li class="sidebar-item">
                    <a href="profil.php">Profil</a>
                </li>
                <li class="sidebar-item">
                    <a href="notifikasi.php">Notifikasi</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
                <li class="sidebar-item">
                    <a href="pengaturan.php">Pengaturan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Profil Dokter</h2>
            </header>
            <div class="app-content-body">
                <!-- Display Message -->
                <?php if (isset($message)) echo $message; ?>
                
                <!-- Form Edit Profil Dokter -->
                <div class="form-container">
                    <h2>Profil Dokter</h2>
                    <form method="POST" action="update_profil.php">
                    <div class="profile-item">
                        <label>Nama Lengkap:</label>
                        <p><?php echo htmlspecialchars($nama_dokter); ?></p>
                    </div>
                    <div class="profile-item">
                        <label>Spesialisasi:</label>
                        <p><?php echo htmlspecialchars($spesialisasi); ?></p>
                    </div>
                    <div class="profile-item">
                        <label>Nomor Telepon:</label>
                        <p><?php echo htmlspecialchars($nomor_telepon); ?></p>
                    </div>
                    <div class="profile-item">
                        <label>Jadwal Praktik:</label>
                        <p><?php echo htmlspecialchars($jadwal_praktik); ?></p>
                    </div>
                    <div class="profile-item">
                        <label>Email:</label>
                        <p><?php echo htmlspecialchars($email); ?></p>
                    </div>
                   
                        <button type="submit" class="btn btn-update">Update Profil</button>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
