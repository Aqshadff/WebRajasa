<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Ambil data dari form
$nama_obat = $_POST['nama_obat'];
$jenis_obat = $_POST['jenis_obat'];
$stok = $_POST['stok'];
$harga = $_POST['harga'];

// Validasi data
if (empty($nama_obat) || empty($jenis_obat) || empty($stok) || empty($harga)) {
    echo "Semua field harus diisi.";
    exit();
}

// Masukkan data ke database
$sql = "INSERT INTO obat (nama_obat, jenis_obat, stok, harga) 
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $nama_obat, $jenis_obat, $stok, $harga);

if ($stmt->execute()) {
    // Redirect setelah berhasil
    header("Location: kelola_obat.php");
    exit();
} else {
    echo "Terjadi kesalahan: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>