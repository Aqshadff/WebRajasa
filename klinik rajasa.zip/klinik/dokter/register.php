<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Dokter</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .register-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }

        .register-container h2 {
            margin-bottom: 30px;
            font-size: 28px;
            color: #333;
            font-weight: 600;
        }

        .input-group {
            position: relative;
            margin-bottom: 30px;
            text-align: left;
        }

        .input-group input{
            width: 100%;
            padding: 15px;
            padding-left: 25px;
            border: none;
            border-radius: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            font-size: 16px;
        }
        .input-group select {
            width: 100%;
            padding: 15px;
            padding-left: 25px;
            border: none;
            border-radius: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            font-size: 16px;
        }

        .input-group label {
            position: absolute;
            left: 20px;
            top: -20px;
            padding: 0 5px;
            font-size: 14px;
            color: #888;
        }

        .register-btn {
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            font-size: 18px;
            transition: all 0.4s;
            width: 100%;
            margin-top: 20px;
        }

        .register-btn:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .register-container a {
            display: block;
            margin-top: 15px;
            text-decoration: none;
            color: #333;
            font-size: 14px;
            transition: color 0.3s;
        }

        .register-container a:hover {
            color: #3a1c71;
        }
    </style>
</head>

<body>
    <div class="register-container">
        <h2>Register Dokter</h2>
        <form action="proses_register.php" method="POST">
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Username" required>
            </div>
            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Email" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Password" required>
            </div>
            
            <button type="submit" class="register-btn">Register</button>
        </form>
        <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>
</body>

</html>
