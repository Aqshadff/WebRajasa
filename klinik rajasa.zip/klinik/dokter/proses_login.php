<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

$username = mysqli_real_escape_string($conn, $username);

$sql = "SELECT * FROM dokter WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    if (password_verify($password, $row['password'])) {
        $_SESSION['id_dokter'] = $row['id_dokter'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['email'] = $row['email'];
        
        header('Location: dashboard.php');
        exit();
    } else {
        echo "Username atau password salah. <a href='login.php'>Kembali ke halaman login</a>";
    }
} else {
    echo "Username atau password salah. <a href='login.php'>Kembali ke halaman login</a>";
}

$stmt->close();
$conn->close();
?>
