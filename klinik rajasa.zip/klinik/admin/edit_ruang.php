<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Cek apakah ID ruang ada di URL dan valid
if (isset($_GET['id_ruang']) && ctype_digit($_GET['id_ruang'])) {
    $id_ruang = $_GET['id_ruang'];

    // Fetch data ruang
    $sql = "SELECT * FROM ruang WHERE id_ruang = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_ruang);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Ruang tidak ditemukan.";
        exit();
    }
} else {
    echo "ID ruang tidak ditemukan atau tidak valid.";
    exit();
}

// Proses form saat disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_ruang = $_POST['nama_ruang'];
    $lokasi = $_POST['lokasi'];
    $kapasitas = $_POST['kapasitas'];
    $status = $_POST['status'];

    // Validasi input agar tidak ada field yang kosong
    if (empty($nama_ruang) || empty($lokasi) || empty($kapasitas) || empty($status)) {
        echo "Semua field harus diisi.";
    } else {
        $sql = "UPDATE ruang SET nama_ruang = ?, lokasi = ?, kapasitas = ?, status = ? WHERE id_ruang = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssisi", $nama_ruang, $lokasi, $kapasitas, $status, $id_ruang);

        if ($stmt->execute()) {
            header("Location: kelola_ruang.php?status=sukses");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Ruang</title>
    <link rel="stylesheet" href="../css/styles3.css">
</head>

<body>
    <div class="app-container">
    <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item active">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
            <div class="account-info">
                
            
            </div>
        </aside>
        <div class="container">
            <header class="app-content-header">
                <h2>Edit Ruang</h2>
            </header>
            <form action="edit_pasien.php?id=<?php echo htmlspecialchars($id_pasien); ?>" method="post">
                <label for="nama_pasien">Nama Pasien:</label> <label for="nama_pasien"></label>
                <input type="text" id="nama_pasien" name="nama_pasien"
                    value="<?php echo htmlspecialchars($pasien['nama_pasien']); ?>" required>

                <label for="alamat">Alamat:</label>
                <input type="text" id="alamat" name="alamat" value="<?php echo htmlspecialchars($pasien['alamat']); ?>"
                    required>

                <label for="tanggal_lahir">Tanggal Lahir:</label>
                <input type="date" id="tanggal_lahir" name="tanggal_lahir"
                    value="<?php echo htmlspecialchars($pasien['tanggal_lahir']); ?>" required>

                <label for="nomor_telepon">Nomor Telepon:</label>
                <input type="text" id="nomor_telepon" name="nomor_telepon"
                    value="<?php echo htmlspecialchars($pasien['nomor_telepon']); ?>" required>

                <label for="jenis_kelamin">Jenis Kelamin:</label>
                <select id="jenis_kelamin" name="jenis_kelamin" required>
                    <option value="Laki-laki" <?php echo ($pasien['jenis_kelamin'] === 'Laki-laki') ? 'selected' : ''; ?>>
                        Laki-laki</option>
                    <option value="Perempuan" <?php echo ($pasien['jenis_kelamin'] === 'Perempuan') ? 'selected' : ''; ?>>
                        Perempuan</option>
                </select>

                <div class="mb-3">
                    <label for="golongan_darah" class="form-label">Golongan Darah</label>
                    <select id="golongan_darah" name="golongan_darah" class="form-select" required>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="AB">AB</option>
                        <option value="O">O</option>
                    </select>
                </div>
                <div class="mb-3">
                        <label for="status_pernikahan" class="form-label">Status Pernikahan</label>
                        <select id="status_pernikahan" name="status_pernikahan" class="form-select" required>
                            <option value="Belum Menikah">Belum Menikah</option>
                            <option value="Menikah">Menikah</option>
                            <option value="Cerai">Cerai</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="jenis_pembayaran" class="form-label">Jenis Pembayaran:</label>
                        <select class="form-control" id="jenis_pembayaran" name="jenis_pembayaran" required>
                            <option value="Tunai">Tunai</option>
                            <option value="Kartu Kredit">Kartu Kredit</option>
                            <option value="Transfer Bank">Transfer Bank</option>
                        </select>
                    </div>

                <input type="submit" value="Simpan Perubahan">
            </form>
        </div>
    </div>
</body>

</html>