<?php
session_start();

// Pastikan pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Jika form di-submit, lakukan update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_dokter = $_POST['nama_dokter'];
    $spesialisasi = $_POST['spesialisasi'];
    $nomor_telepon = $_POST['nomor_telepon'];
    $jadwal_praktik = $_POST['jadwal_praktik'];
    $email = $_POST['email'];
    $username = $_SESSION['username'];

    // Update data ke dalam database
    $sql = "UPDATE dokter SET nama_dokter = ?, spesialisasi = ?, nomor_telepon = ?, jadwal_praktik = ?, email = ? WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $nama_dokter, $spesialisasi, $nomor_telepon, $jadwal_praktik, $email, $username);

    if ($stmt->execute()) {
        // Jika berhasil, arahkan kembali ke halaman profil
        header("Location: profil.php");
        exit();
    } else {
        echo "Gagal memperbarui profil: " . $conn->error;
    }
}

// Ambil data profil dokter dari tabel pengguna
$username = $_SESSION['username'];
$sql = "SELECT * FROM dokter WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nama_dokter = $row['nama_dokter'];
    $spesialisasi = $row['spesialisasi'];
    $nomor_telepon = $row['nomor_telepon'];
    $jadwal_praktik = $row['jadwal_praktik'];
    $email = $row['email'];
} else {
    echo "Data tidak ditemukan.";
    exit();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Dokter - Dokter Panel</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
        }

        .app-container {
            display: flex;
            flex-direction: row;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            position: fixed;
            height: 100%;
            overflow-y: auto;
        }

        .sidebar-header h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }

        .sidebar-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-item {
            margin-bottom: 10px;
        }

        .sidebar-item a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar-item a:hover {
            background: #f0f0f0;
        }

        .app-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            overflow-y: auto;
        }

        .app-content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .app-content-body {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .form-container {
            background: #f9f9f9;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            margin-bottom: 20px;
        }

        .form-container .form-label {
            font-weight: bold;
        }

        .btn-update {
            background-color: #3a1c71;
            color: #fff;
            border: none;
        }

        .btn-update:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            .app-container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                max-width: none;
                position: static;
                box-shadow: none;
            }

            .app-content {
                margin-left: 0;
                margin-top: 20px;
            }
        }
    </style>
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Dokter Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard_dokter.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="data_rekam_medis.php">Data Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="jadwal_kunjungan.php">Jadwal Kunjungan</a>
                </li>
                <li class="sidebar-item">
                    <a href="profil.php">Profil</a>
                </li>
                <li class="sidebar-item">
                    <a href="notifikasi.php">Notifikasi</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
                <li class="sidebar-item">
                    <a href="pengaturan.php">Pengaturan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Profil Dokter</h2>
            </header>
            <div class="app-content-body">
                <!-- Display Message -->
                <?php if (isset($message)) echo $message; ?>
                
                <!-- Form Edit Profil Dokter -->
                <div class="form-container">
                    <h2>Update Profil</h2>
                    <form method="POST" action="profil.php">
                        <div class="form-group mb-3">
                            <label for="nama_dokter" class="form-label">Nama Lengkap:</label>
                            <input type="text" class="form-control" id="nama_dokter" name="nama_dokter" value="<?php echo htmlspecialchars($nama_dokter); ?>" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="spesialisasi" class="form-label">Spesialisasi:</label>
                            <input type="text" class="form-control" id="spesialisasi" name="spesialisasi" value="<?php echo htmlspecialchars($spesialisasi); ?>" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="nomor_telepon" class="form-label">Nomor Telepon:</label>
                            <input type="text" class="form-control" id="nomor_telepon" name="nomor_telepon" value="<?php echo htmlspecialchars($nomor_telepon); ?>" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="jadwal_praktik" class="form-label">Jadwal Praktik:</label>
                            <input type="text" class="form-control" id="jadwal_praktik" name="jadwal_praktik" value="<?php echo htmlspecialchars($jadwal_praktik); ?>" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                        </div>
                        <button type="submit" class="btn btn-update">Update Profil</button>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
