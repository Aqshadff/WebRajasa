<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek apakah ID dokter ada di URL dan valid
if (isset($_GET['id_dokter']) && ctype_digit($_GET['id_dokter'])) {
    $id_dokter = $_GET['id_dokter'];

    // Cek apakah dokter ada di database
    $sql = "SELECT * FROM dokter WHERE id_dokter = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_dokter);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Jika ditemukan, hapus dokter
        $sql_delete = "DELETE FROM dokter WHERE id_dokter = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("i", $id_dokter);
        
        if ($stmt_delete->execute()) {
            header("Location: kelola_dokter.php?status=sukses");
            exit();
        } else {
            echo "Gagal menghapus data dokter.";
        }
    } else {
        echo "Dokter dengan ID tersebut tidak ditemukan.";
    }
} else {
    echo "ID dokter tidak ditemukan atau tidak valid.";
}

$conn->close();
?>
