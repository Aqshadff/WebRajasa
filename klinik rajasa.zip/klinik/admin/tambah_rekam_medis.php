<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin" atau "Dokter"
if (!isset($_SESSION['username']) || ($_SESSION['role'] !== 'Admin' && $_SESSION['role'] !== 'Dokter')) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses form saat disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pasien = $_POST['id_pasien'];
    $id_dokter = $_POST['id_dokter'];
    $tanggal_kunjungan = $_POST['tanggal_kunjungan'];
    $diagnosa = $_POST['diagnosa'];
    $tindakan = $_POST['tindakan'];
    $resep_obat = $_POST['resep_obat'];
    $catatan = $_POST['catatan'];
    $alergi = $_POST['alergi'];

    $sql = "INSERT INTO rekam_medis (id_pasien, id_dokter, tanggal_kunjungan, diagnosa, tindakan, resep_obat, catatan, alergi)
            VALUES ('$id_pasien', '$id_dokter', '$tanggal_kunjungan', '$diagnosa', '$tindakan', '$resep_obat', '$catatan', '$alergi')";

    if ($conn->query($sql) === TRUE) {
        header("Location: kelola_rekam_medis.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Ambil data pasien, dokter, dan obat untuk pilihan dropdown
$pasien_result = $conn->query("SELECT id_pasien, nama_pasien FROM pasien");
$dokter_result = $conn->query("SELECT id_dokter, nama_dokter FROM dokter");
$obat_result = $conn->query("SELECT id_obat, nama_obat FROM obat");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Rekam Medis</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item active">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Tambah Rekam Medis</h2>
            </header>
            <div class="app-content-body">
                <form action="proses_tambah_rekam_medis.php" method="POST">
                    <div class="mb-3">
                        <label for="id_pasien" class="form-label">Pasien</label>
                        <select class="form-select" id="id_pasien" name="id_pasien" required>
                            <option value="">Pilih Pasien</option>
                            <?php
                            if ($pasien_result->num_rows > 0) {
                                while ($row = $pasien_result->fetch_assoc()) {
                                    echo "<option value='" . $row['id_pasien'] . "'>" . htmlspecialchars($row['nama_pasien']) . "</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="id_dokter" class="form-label">Dokter</label>
                        <select class="form-select" id="id_dokter" name="id_dokter" required>
                            <option value="">Pilih Dokter</option>
                            <?php
                            if ($dokter_result->num_rows > 0) {
                                while ($row = $dokter_result->fetch_assoc()) {
                                    echo "<option value='" . $row['id_dokter'] . "'>" . htmlspecialchars($row['nama_dokter']) . "</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tanggal_kunjungan" class="form-label">Tanggal Kunjungan</label>
                        <input type="date" class="form-control" id="tanggal_kunjungan" name="tanggal_kunjungan"
                            required>
                    </div>
                    <div class="mb-3">
                        <label for="diagnosa" class="form-label">Diagnosa</label>
                        <textarea class="form-control" id="diagnosa" name="diagnosa" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="tindakan" class="form-label">Tindakan</label>
                        <textarea class="form-control" id="tindakan" name="tindakan" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="resep_obat" class="form-label">Resep Obat</label>
                        <select class="form-select" id="resep_obat" name="resep_obat" required>
                            <option value="">Pilih Obat</option>
                            <?php
                            if ($obat_result->num_rows > 0) {
                                while ($row = $obat_result->fetch_assoc()) {
                                    echo "<option value='" . $row['id_obat'] . "'>" . htmlspecialchars($row['nama_obat']) . "</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="catatan" class="form-label">Catatan</label>
                        <textarea class="form-control" id="catatan" name="catatan" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="alergi" class="form-label">Alergi</label>
                        <textarea class="form-control" id="alergi" name="alergi" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
$conn->close();
?>
