<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";  // Ganti dengan nama database Anda

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Jangan menambahkan echo di sini
?>
