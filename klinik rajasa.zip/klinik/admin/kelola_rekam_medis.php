<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $id_rekam_medis = $_GET['delete_id'];

    $sql = "DELETE FROM rekam_medis WHERE id_rekam_medis = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_rekam_medis);

    if ($stmt->execute()) {
        echo "Rekam medis berhasil dihapus.";
    } else {
        echo "Terjadi kesalahan: " . $stmt->error;
    }

    $stmt->close();
}

// Handle search
$search = $_GET['search'] ?? '';
$search_param = '%' . $search . '%';

// Query dengan JOIN dan pencarian
$sql = "SELECT rekam_medis.*, pasien.nama_pasien, dokter.nama_dokter, obat.nama_obat
        FROM rekam_medis
        JOIN pasien ON rekam_medis.id_pasien = pasien.id_pasien
        JOIN dokter ON rekam_medis.id_dokter = dokter.id_dokter
        JOIN obat ON rekam_medis.resep_obat = obat.id_obat
        WHERE pasien.nama_pasien LIKE ? OR dokter.nama_dokter LIKE ? OR obat.nama_obat LIKE ?";

$stmt = $conn->prepare($sql);

// Cek apakah prepare berhasil
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("sss", $search_param, $search_param, $search_param);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    echo "Query Error: " . $conn->error;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Rekam Medis</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
    .button-group {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.export-form {
    display: flex;
    align-items: center;
}

.export-form button {
    margin-right: 10px;
}

.search-form {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.search-form .form-control {
    margin-bottom: 10px;
}

.search-form button {
    display: flex;
    align-items: center;
}

.search-form i {
    margin-right: 5px;
}

    </style>
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item active">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Rekam Medis</h2>
                <a href="tambah_rekam_medis.php" class="btn btn-primary">Tambah Rekam Medis</a>
            </header>
            <div class="app-content2-body">
    <div class="button-group">
        <form method="POST" action="export_rekam_medis.php">
            <button type="submit" class="btn btn-secondary">
                <i class="fas fa-file-csv"></i> CSV
            </button>
        </form>
        <form method="GET" action="">
            <div class="mb-3">
                <input type="text" class="form-control" name="search" placeholder="Cari rekam medis"
                    value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-search"></i> Cari
            </button>
        </form>
    </div>
</div>

                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Pasien</th>
                            <th>Dokter</th>
                            <th>Tanggal Kunjungan</th>
                            <th>Diagnosa</th>
                            <th>Tindakan</th>
                            <th>Resep Obat</th>
                            <th>Catatan</th>
                            <th>Alergi</th>
                            <th>Detail</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['nama_pasien']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_dokter']); ?></td>
                                <td><?php echo htmlspecialchars($row['tanggal_kunjungan']); ?></td>
                                <td><?php echo htmlspecialchars($row['diagnosa']); ?></td>
                                <td><?php echo htmlspecialchars($row['tindakan']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_obat']); ?></td>
                                <td><?php echo htmlspecialchars($row['catatan']); ?></td>
                                <td><?php echo htmlspecialchars($row['alergi']); ?></td>
                                <td><a href="detail_rekam_medis.php?id_rekam_medis=<?php echo htmlspecialchars($row['id_rekam_medis']); ?>">Detail</a></td>
                                <td>
                                    <a href="edit_rekam_medis.php?id_rekam_medis=<?php echo htmlspecialchars($row['id_rekam_medis']); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="kelola_rekam_medis.php?delete_id=<?php echo htmlspecialchars($row['id_rekam_medis']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- JavaScript for Bootstrap -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
