<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $id_rekam_medis = $_GET['delete_id'];

    $sql = "DELETE FROM rekam_medis WHERE id_rekam_medis = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_rekam_medis);

    if ($stmt->execute()) {
        echo "Rekam medis berhasil dihapus.";
    } else {
        echo "Terjadi kesalahan: " . $stmt->error;
    }

    $stmt->close();
}

// Parameter pencarian
$search_param = isset($_GET['search']) ? '%' . $_GET['search'] . '%' : '%';

// Query dengan JOIN dan pencarian
$sql = "SELECT rekam_medis.*, pasien.nama_pasien, dokter.nama_dokter, obat.nama_obat
        FROM rekam_medis
        JOIN pasien ON rekam_medis.id_pasien = pasien.id_pasien
        JOIN dokter ON rekam_medis.id_dokter = dokter.id_dokter
        JOIN obat ON rekam_medis.resep_obat = obat.id_obat
        WHERE pasien.nama_pasien LIKE ? OR dokter.nama_dokter LIKE ? OR obat.nama_obat LIKE ?";

$stmt = $conn->prepare($sql);

// Cek apakah prepare berhasil
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("sss", $search_param, $search_param, $search_param);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    echo "Query Error: " . $conn->error;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Rekam Medis - Dokter Panel</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
        }

        .app-container {
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .sidebar-header h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }

        .sidebar-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-item {
            margin-bottom: 10px;
        }

        .sidebar-item a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar-item a:hover {
            background: #f0f0f0;
        }

        .app-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .app-content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .app-content-body {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .form-container {
            background: #f9f9f9;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .table-container {
            margin-top: 20px;
        }

        .table-container table {
            width: 100%;
            border-collapse: collapse;
        }

        .table-container th,
        .table-container td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .table-container th {
            background-color: #f0f0f0;
        }

        .btn-edit,
        .btn-delete {
            margin: 0 5px;
        }

        .btn-edit {
            color: #007bff;
        }

        .btn-delete {
            color: #dc3545;
        }
    </style>
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Dokter Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard_dokter.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="data_rekam_medis.php">Data Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="jadwal_kunjungan.php">Jadwal Kunjungan</a>
                </li>
                <li class="sidebar-item">
                    <a href="profil.php">Profil</a>
                </li>
                <li class="sidebar-item">
                    <a href="notifikasi.php">Notifikasi</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
                <li class="sidebar-item">
                    <a href="pengaturan.php">Pengaturan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Data Rekam Medis</h2>
            </header>
            <div class="app-content-body">
                

                <!-- Tabel Rekam Medis -->
                <div class="table-container">
                    <h3>Daftar Rekam Medis</h3>
                    <table>
                        <thead>
                            <tr>
                            <th>Pasien</th>
                            <th>Dokter</th>
                            <th>Tanggal Kunjungan</th>
                            <th>Diagnosa</th>
                            <th>Tindakan</th>
                            <th>Resep Obat</th>
                            <th>Catatan</th>
                            <th>Alergi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['nama_pasien']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_dokter']); ?></td>
                                <td><?php echo htmlspecialchars($row['tanggal_kunjungan']); ?></td>
                                <td><?php echo htmlspecialchars($row['diagnosa']); ?></td>
                                <td><?php echo htmlspecialchars($row['tindakan']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_obat']); ?></td>
                                <td><?php echo htmlspecialchars($row['catatan']); ?></td>
                                <td><?php echo htmlspecialchars($row['alergi']); ?></td>
                                
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
