<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_klinik";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek apakah ID rekam_medis ada di URL dan valid
if (isset($_GET['id_rekam_medis']) && ctype_digit($_GET['id_rekam_medis'])) {
    $id_rekam_medis = $_GET['id_rekam_medis'];

    // Cek apakah rekam_medis ada di database
    $sql = "SELECT * FROM rekam_medis WHERE id_rekam_medis = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_rekam_medis);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Jika ditemukan, hapus rekam_medis
        $sql_delete = "DELETE FROM rekam_medis WHERE id_rekam_medis = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("i", $id_rekam_medis);
        
        if ($stmt_delete->execute()) {
            header("Location: kelola_rekam_medis.php?status=sukses");
            exit();
        } else {
            echo "Gagal menghapus data rekam_medis.";
        }
    } else {
        echo "rekam medis dengan ID tersebut tidak ditemukan.";
    }
} else {
    echo "ID rekam medis tidak ditemukan atau tidak valid.";
}

$conn->close();
?>
