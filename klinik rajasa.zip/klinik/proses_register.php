<?php
session_start(); // Memulai sesi untuk menyimpan data login

// Menghubungkan ke database
$servername = "localhost";
$username = "root"; // Sesuaikan dengan username database Anda
$password = ""; // Sesuaikan dengan password database Anda
$dbname = "klinik_db";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mendapatkan data dari form
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$konfirmasi_password = $_POST['confirm_password'];

// Validasi apakah password dan konfirmasi password sesuai
if ($password !== $konfirmasi_password) {
    echo "Password dan konfirmasi password tidak sesuai.";
    exit();
}

// Enkripsi password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// SQL untuk memasukkan data pengguna baru ke tabel `pengguna`
$sql = "INSERT INTO pengguna(username, email, password, role) VALUES (?, ?, ?, '?')";

// Mempersiapkan pernyataan SQL
$stmt = $conn->prepare($sql);

// Pastikan pernyataan berhasil dipersiapkan
if ($stmt === false) {
    die("Error: " . $conn->error);
}

// Mengikat parameter
$stmt->bind_param("sss", $username, $email, $hashed_password);

// Menjalankan pernyataan SQL dan memeriksa apakah berhasil
if ($stmt->execute()) {
    // Jika registrasi berhasil, login otomatis
    $_SESSION['user'] = [
        'username' => $username,
        'email' => $email,
        'role' => 'Pasien'
    ];
    // Redirect ke halaman setelah login, misalnya dashboard
    header("Location: login.php");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Menutup koneksi
$stmt->close();
$conn->close();
?>
