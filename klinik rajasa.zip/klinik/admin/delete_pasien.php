<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Ambil ID pasien dari URL
$id_pasien = $_GET['id_pasien'];

// Hapus data pasien dari database
$sql = "DELETE FROM pasien WHERE id_pasien = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_pasien);

if ($stmt->execute()) {
    // Redirect setelah berhasil dihapus
    header("Location: view_users.php");
    exit();
} else {
    echo "Terjadi kesalahan: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
