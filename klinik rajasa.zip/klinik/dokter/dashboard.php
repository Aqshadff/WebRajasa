<?php
session_start();
if (!isset($_SESSION['username'])) {
    echo "Session belum diatur. <a href='login.php'>Login</a>";
    exit();
}

// Koneksi ke database
include 'koneksi.php';

// Hitung jumlah kunjungan hari ini
$sql = "SELECT COUNT(*) AS kunjungan_hari_ini FROM rekam_medis WHERE tanggal_kunjungan = CURDATE()";
$result = $conn->query($sql);
if ($result) {
    $kunjungan_hari_ini = $result->fetch_assoc()['kunjungan_hari_ini'];
} else {
    die("Query gagal: " . $conn->error);
}

// Hitung total rekam medis
$sql = "SELECT COUNT(*) AS total_rekam_medis FROM rekam_medis";
$result = $conn->query($sql);
if ($result) {
    $total_rekam_medis = $result->fetch_assoc()['total_rekam_medis'];
} else {
    die("Query gagal: " . $conn->error);
}

// Ambil data pasien terbaru (misalnya 5 pasien terbaru)
$sql = "SELECT * FROM pasien ORDER BY tanggal_register DESC LIMIT 5";
$result = $conn->query($sql);
$recent_patients = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $recent_patients[] = $row;
    }
} else {
    die("Query gagal: " . $conn->error);
}

// Ambil jadwal kunjungan dokter untuk hari ini
$sql = "SELECT * FROM jadwal_kunjungan WHERE id_dokter = ? AND tanggal_kunjungan = CURDATE()";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Prepare statement gagal: " . htmlspecialchars($conn->error));
}

$stmt->bind_param('i', $_SESSION['id_dokter']);
$stmt->execute();

if ($stmt->error) {
    die("Execute statement gagal: " . htmlspecialchars($stmt->error));
}

$result = $stmt->get_result();
$schedule_today = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $schedule_today[] = $row;
    }
} else {
    die("Query gagal: " . htmlspecialchars($stmt->error));
}

// Ambil rekam medis terbaru untuk pasien
$sql = "SELECT * FROM rekam_medis ORDER BY tanggal_kunjungan DESC LIMIT 5";
$result = $conn->query($sql);
$recent_records = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $recent_records[] = $row;
    }
} else {
    die("Query gagal: " . htmlspecialchars($conn->error));
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Dokter</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
        }

        .app-container {
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .sidebar-header h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }

        .sidebar-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-item {
            margin-bottom: 10px;
        }

        .sidebar-item a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar-item a:hover {
            background: #f0f0f0;
        }

        .app-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .app-content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .app-content-body {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .dashboard-summary {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .summary-item {
            flex: 1;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            color: #fff;
            transition: transform 0.3s ease;
        }

        .summary-item:hover {
            transform: translateY(-5px);
        }

        .summary-item h3 {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .summary-item p {
            font-size: 2rem;
            margin: 0;
        }

        .summary-item i {
            font-size: 3rem;
            display: block;
            margin-bottom: 10px;
        }

        .summary-item-kunjungan {
            background-color: #e74c3c; /* Merah */
        }

        .summary-item-rekam-medis {
            background-color: #9b59b6; /* Ungu */
        }

        .summary-item-pasien {
            background-color: #3498db; /* Biru */
        }

        .recent-patients,
        .recent-records,
        .schedule-today {
            margin-top: 20px;
        }

        .recent-patients table,
        .recent-records table,
        .schedule-today table {
            width: 100%;
            border-collapse: collapse;
        }

        .recent-patients th,
        .recent-patients td,
        .recent-records th,
        .recent-records td,
        .schedule-today th,
        .schedule-today td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .recent-patients th,
        .recent-records th,
        .schedule-today th {
            background-color: #f0f0f0;
        }
    </style>
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Dokter Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="data_rekam_medis.php">Data Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="janji_temu_pasien.php">Janji Temu Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="profil.php">Profil</a>
                </li>
                <li class="sidebar-item">
                    <a href="notifikasi.php">Notifikasi</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
                <li class="sidebar-item">
                    <a href="pengaturan.php">Pengaturan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Selamat datang, <?php echo htmlspecialchars($_SESSION['username']); ?></h2>
            </header>
            <div class="app-content-body">
                <div class="dashboard-summary">
                    <div class="summary-item summary-item-kunjungan">
                        <i class="fas fa-calendar-day"></i>
                        <h3>Kunjungan Hari Ini</h3>
                        <p><?php echo $kunjungan_hari_ini; ?></p>
                    </div>
                    <div class="summary-item summary-item-rekam-medis">
                        <i class="fas fa-file-medical"></i>
                        <h3>Total Rekam Medis</h3>
                        <p><?php echo $total_rekam_medis; ?></p>
                    </div>
                    <div class="summary-item summary-item-pasien">
                        <i class="fas fa-user-injured"></i>
                        <h3>Pasien Terbaru</h3>
                        <p><?php echo count($recent_patients); ?> Terbaru</
                        </p>
                    </div>
                </div>
                <div class="recent-patients">
                    <h3>Pasien Terbaru</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Tanggal Registrasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                         $no = 1; // Memulai nomor urut dari 1
                        foreach ($recent_patients as $patient): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($patient['id_pasien']); ?></td>
                                <td><?php echo htmlspecialchars($patient['nama_pasien']); ?></td>
                                <td><?php echo htmlspecialchars($patient['alamat']); ?></td>
                                <td><?php echo htmlspecialchars($patient['tanggal_register']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="recent-records">
                    <h3>Rekam Medis Terbaru</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Dokter</th>
                                <th>Pasien</th>
                                <th>Diagnosa</th>
                                <th>Tanggal Kunjungan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_records as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['id_rekam_medis']); ?></td>
                                <td><?php echo htmlspecialchars($record['id_pasien']); ?></td>
                                <td><?php echo htmlspecialchars($record['diagnosa']); ?></td>
                                <td><?php echo htmlspecialchars($record['tanggal_kunjungan']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="schedule-today">
                    <h3>Jadwal Kunjungan Hari Ini</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Pasien</th>
                                <th>Waktu</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($schedule_today as $schedule): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($schedule['id_jadwal']); ?></td>
                                <td><?php echo htmlspecialchars($schedule['nama_pasien']); ?></td>
                                <td><?php echo htmlspecialchars($schedule['waktu']); ?></td>
                                <td><?php echo htmlspecialchars($schedule['keterangan']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
