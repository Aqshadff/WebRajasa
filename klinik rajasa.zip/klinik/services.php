<?php
include 'koneksi.php';

$sql = "SELECT * FROM services";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layanan - Klinik Sehat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
            background: #f0f2f5;
        }

        header {
            background: linear-gradient(90deg, #007bff, #00aaff);
            color: #fff;
            padding: 1rem 0;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }

        header:hover {
            background: linear-gradient(90deg, #0056b3, #007bff);
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: auto;
            padding: 0 1rem;
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #fff;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
            transition: color 0.3s ease;
        }

        .navbar-brand:hover {
            color: #d1e7fd;
        }

        .navbar-nav {
            display: flex;
            gap: 1.5rem;
        }

        .navbar-nav a {
            color: #fff;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s;
            position: relative;
        }

        .navbar-nav a::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 2px;
            background: #fff;
            transition: width 0.3s, left 0.3s;
        }

        .navbar-nav a:hover::after {
            width: 100%;
            left: 0;
        }

        .navbar-nav a:hover {
            background-color: #0056b3;
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: auto;
            overflow: hidden;
            padding: 2rem 1rem;
            margin-top: 5rem; /* Offset for fixed header */
        }

        h1, h2 {
            color: #007bff;
            transition: color 0.3s, transform 0.3s;
            margin-bottom: 1rem;
        }

        h1:hover, h2:hover {
            color: #0056b3;
            transform: scale(1.05);
        }

        .section {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            padding: 1.5rem;
            transition: box-shadow 0.3s, transform 0.3s;
        }

        .section:hover {
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            transform: translateY(-5px);
        }

        .service-card {
            display: flex;
            align-items: center;
            background: #e9ecef;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s, transform 0.3s;
            cursor: pointer;
        }

        .service-card img {
            border-radius: 50%;
            width: 80px;
            height: 80px;
            object-fit: cover;
            margin-right: 1rem;
        }

        .service-card:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transform: scale(1.02);
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            transition: opacity 0.3s ease;
        }

        .modal-content {
            background: #fff;
            padding: 2rem;
            border-radius: 8px;
            max-width: 90%;
            max-height: 80%;
            overflow: hidden;
        }

        .modal-content img {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .modal-close {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #333;
            color: #fff;
            border: none;
            border-radius: 50%;
            padding: 10px;
            font-size: 1.2rem;
            cursor: pointer;
        }

        .modal-close:hover {
            background: #555;
        }

        footer {
            background: #343a40;
            color: #fff;
            text-align: center;
            padding: 1rem 0;
            margin-top: 2rem;
            box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.1);
        }

        footer a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s;
        }

        footer a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>

<header>
    <div class="navbar">
        <div class="navbar-brand">Klinik Sehat</div>
        <div class="navbar-nav">
            <a href="index.php">Beranda</a>
            <a href="services.php">Layanan</a>
            <a href="about.php">About</a>
            <a href="jadwal_dokter.php">Jadwal Dokter</a>
            <a href="contact.php">Contact Me</a>
            <a href="login.php" class="login-btn">Login</a>
        </div>
    </div>
</header>

<div class="container">
    <section class="section">
        <h1>Layanan Kami</h1>
          
        <?php
        while($row = mysqli_fetch_assoc($result)) {
            echo '<div class="service-card" data-img="' . htmlspecialchars($row['gambar']) . '">';
            echo '<img src="' . htmlspecialchars($row['gambar']) . '" alt="' . htmlspecialchars($row['nama']) . '">';
            echo '<div>';
            echo '<h2>' . htmlspecialchars($row['nama']) . '</h2>';
            echo '<p>' . htmlspecialchars($row['deskripsi']) . '</p>';
            echo '</div>';
            echo '</div>';
        }
        ?>
        <div class="service-card" data-img="konsul.jpeg">
            <img src="konsul.jpeg" alt="Konsultasi Medis Umum">
            <div>
                <h2>Konsultasi Medis Umum</h2>
                <p>Konsultasi dengan dokter umum untuk pemeriksaan kesehatan secara menyeluruh dan penanganan berbagai masalah kesehatan sehari-hari.</p>
            </div>
        </div>
        
        <div class="service-card" data-img="spesialis.jpeg">
            <img src="spesialis.jpeg" alt="Perawatan Spesialis">
            <div>
                <h2>Perawatan Spesialis</h2>
                <p>Perawatan oleh dokter spesialis dalam berbagai bidang seperti kulit, paru, dan anak untuk diagnosis dan pengobatan penyakit yang lebih kompleks.</p>
            </div>
        </div>
        
        <div class="service-card" data-img="labor.jpeg">
            <img src="labor.jpeg" alt="Layanan Laboratorium">
            <div>
                <h2>Layanan Laboratorium</h2>
                <p>Berbagai tes laboratorium untuk mendiagnosis kondisi kesehatan melalui analisis sampel darah, urin, dan tes lainnya.</p>
            </div>
        </div>
        
        <div class="service-card" data-img="radiologi.jpeg">
            <img src="radiologi.jpeg" alt="Layanan Radiologi">
            <div>
                <h2>Layanan Radiologi</h2>
                <p>Prosedur imaging seperti X-ray, USG, dan CT scan untuk membantu diagnosis dan penanganan penyakit dengan teknologi imaging terkini.</p>
            </div>
        </div>
        
        <div class="service-card" data-img="igd.jpeg">
            <img src="igd.jpeg" alt="Perawatan Darurat">
            <div>
                <h2>Perawatan Darurat</h2>
                <p>Penanganan kasus darurat yang memerlukan perawatan medis segera dan cepat di fasilitas kami yang lengkap.</p>
            </div>
        </div>
        
        <div class="service-card" data-img="kesehatan.jpeg">
            <img src="kesehatan.jpeg" alt="Pemeriksaan Kesehatan Berkala">
            <div>
                <h2>Pemeriksaan Kesehatan Berkala</h2>
                <p>Program pemeriksaan kesehatan berkala untuk menjaga kesehatan dan mendeteksi potensi masalah kesehatan sejak dini.</p>
            </div>
        </div>
        
        <div class="service-card" data-img="vaksin.jpeg">
            <img src="vaksin.jpeg" alt="Vaksinasi dan Imunisasi">
            <div>
                <h2>Vaksinasi dan Imunisasi</h2>
                <p>Layanan vaksinasi untuk melindungi dari penyakit menular dan memastikan kekebalan tubuh tetap optimal.</p>
            </div>
        </div>
        
        <div class="service-card" data-img="rehab.jpeg">
            <img src="rehab.jpeg" alt="Rehabilitasi dan Terapi Fisik">
            <div>
                <h2>Rehabilitasi dan Terapi Fisik</h2>
                <p>Program rehabilitasi dan terapi fisik untuk membantu pemulihan dari cedera atau kondisi medis tertentu melalui terapi dan latihan.</p>
            </div>
        </div>
    </section>
</div>

<!-- Modal -->
<div id="modal" class="modal">
    <div class="modal-content">
        <button class="modal-close">&times;</button>
        <img id="modal-img" src="" alt="Gambar Detail">
    </div>
</div>

<footer>
    <p>&copy; 2024 Klinik Sehat. Semua hak dilindungi. | <a href="#">Kebijakan Privasi</a> | <a href="#">Syarat dan Ketentuan</a></p>
</footer>

<script>
    const serviceCards = document.querySelectorAll('.service-card');
    const modal = document.getElementById('modal');
    const modalImg = document.getElementById('modal-img');
    const modalClose = document.querySelector('.modal-close');

    serviceCards.forEach(card => {
        card.addEventListener('click', () => {
            const imgSrc = card.getAttribute('data-img');
            modalImg.src = imgSrc;
            modal.style.display = 'flex';
        });
    });

    modalClose.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
</script>

</body>
</html>
