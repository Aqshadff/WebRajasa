<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data profil admin dari tabel pengguna
$username = $_SESSION['username'];
$sql = "SELECT * FROM pengguna WHERE username = '$username' AND role = 'Admin'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nama_lengkap = $row['username']; // Sesuaikan dengan kolom yang Anda miliki
    $email = $row['email'];
} else {
    echo "Data tidak ditemukan.";
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Admin</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        .app-content {
            flex: 1;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Poppins', sans-serif;
        }

        .profile-container {
            width: 100%;
            max-width: 700px;
            background-color: #EEEEEE;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .profile-container h2 {
            font-size: 28px;
            margin-bottom: 20px;
            color: #2c3e50;
        }

        .profile-picture {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin: 0 auto 20px;
            background-color: #ecf0f1;
            background-image: url('../clara1.jpeg'); /* Ganti dengan path gambar profil Anda */
            background-size: cover;
            background-position: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .profile-info {
            text-align: left;
        }

        .profile-item {
            margin-bottom: 20px;
        }

        .profile-item label {
            font-weight: bold;
            font-size: 16px;
            color: #34495e;
            display: block;
        }

        .profile-item p {
            margin: 5px 0 0;
            font-size: 18px;
            color: #2c3e50;
            background-color: #f4f6f9;
            padding: 10px;
            border-radius: 5px;
        }

        .edit-profile-btn {
            margin-top: 30px;
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .edit-profile-btn:hover {
            background-color: #2980b9;
        }
    </style>
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <div class="profile-container">
                <div class="profile-picture"></div>
                <h2>Profil Admin</h2>
                <div class="profile-info">
                    <div class="profile-item">
                        <label>Nama Lengkap:</label>
                        <p><?php echo htmlspecialchars($nama_lengkap); ?></p>
                    </div>
                    <div class="profile-item">
                        <label>Username:</label>
                        <p><?php echo htmlspecialchars($username); ?></p>
                    </div>
                    <div class="profile-item">
                        <label>Email:</label>
                        <p><?php echo htmlspecialchars($email); ?></p>
                    </div>
                </div>
                <button class="edit-profile-btn">Edit Profil</button>
            </div>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
