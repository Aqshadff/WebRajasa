<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Query untuk mengambil data janji temu pasien
$sql = "SELECT janji_temu.id_janji_temu, pasien.nama_pasien, dokter.nama_dokter, janji_temu.tanggal_janji, janji_temu.jam_janji, janji_temu.status
        FROM janji_temu
        JOIN pasien ON janji_temu.id_pasien = pasien.id_pasien
        JOIN dokter ON janji_temu.id_dokter = dokter.id_dokter";

$result = $conn->query($sql);

// Cek query error
if (!$result) {
    die("Query Error: " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Janji Temu Pasien - Dokter Panel</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #3a1c71, #d76d77, #ffaf7b);
        }

        .app-container {
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .sidebar-header h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }

        .sidebar-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-item {
            margin-bottom: 10px;
        }

        .sidebar-item a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar-item a:hover {
            background: #f0f0f0;
        }

        .app-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .app-content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .app-content-body {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .form-container {
            background: #f9f9f9;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .table-container {
            margin-top: 20px;
        }

        .table-container table {
            width: 100%;
            border-collapse: collapse;
        }

        .table-container th,
        .table-container td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .table-container th {
            background-color: #f0f0f0;
        }

        .btn-edit,
        .btn-delete {
            margin: 0 5px;
        }

        .btn-edit {
            color: #007bff;
        }

        .btn-delete {
            color: #dc3545;
        }
    </style>
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Dokter Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard_dokter.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="data_rekam_medis.php">Data Rekam Medis</a>
                </li>
                
                <li class="sidebar-item">
                    <a href="janji_temu_pasien.php">Janji Temu Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="profil.php">Profil</a>
                </li>
                <li class="sidebar-item">
                    <a href="notifikasi.php">Notifikasi</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
                <li class="sidebar-item">
                    <a href="pengaturan.php">Pengaturan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Janji Temu Pasien</h2>
            </header>
            <div class="app-content-body">
                <!-- Tabel Janji Temu Pasien -->
                <div class="table-container">
                    <h3>Daftar Janji Temu Pasien</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Pasien</th>
                                <th>Dokter</th>
                                <th>Tanggal Janji</th>
                                <th>Jam Janji</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id_janji_temu']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_pasien']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_dokter']); ?></td>
                                <td><?php echo htmlspecialchars($row['tanggal_janji']); ?></td>
                                <td><?php echo htmlspecialchars($row['jam_janji']); ?></td>
                                <td><?php echo htmlspecialchars($row['status']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
