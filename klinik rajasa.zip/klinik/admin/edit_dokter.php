<?php
session_start();
include 'koneksi.php';


// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Ambil ID pasien dari parameter GET
$id_dokter = isset($_GET['id']) ? intval($_GET['id']) : 0; // Ubah 'id_dokter' menjadi 'id'

if ($id_dokter <= 0) {
    echo "ID dokter tidak valid.";
    exit();
}

// Ambil data dokter dari database
$sql = "SELECT * FROM dokter WHERE id_dokter = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_dokter);
$stmt->execute();
$result = $stmt->get_result();
$dokter = $result->fetch_assoc();

if (!$dokter) {
    echo "Data dokter tidak ditemukan.";
    exit();
}

// Jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_dokter = $_POST['nama_dokter'];
    $spesialisasi = $_POST['spesialisasi'];
    $nomor_telepon = $_POST['nomor_telepon'];
    $jadwal_praktik = $_POST['jadwal_praktik'];
    $email = $_POST['email'];


    // Validasi data
    if (empty($nama_dokter) || empty($spesialisasi) || empty($nomor_telepon) || empty($email) || empty($jadwal_praktik)) {
        echo "Semua field harus diisi.";
        exit();
    }

    // Update data pasien
    $sql = "UPDATE dokter SET nama_dokter = ?, spesialisasi = ?,  nomor_telepon = ?, jadwal_praktik = ?, email = ? WHERE id_dokter = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $nama_dokter, $spesialisasi, $nomor_telepon, $jadwal_praktik, $email, $id_dokter);

    if ($stmt->execute()) {
        header("Location: kelola_dokter.php");
        exit();
    } else {
        echo "Terjadi kesalahan: " . $stmt->error;
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Dokter</title>
    <link rel="stylesheet" href="../css/styles3.css">
</head>

<body>
    <div class="app-container">
    <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item active">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
            <div class="account-info">
                
            
            </div>
        </aside>
        <div class="container">
            <header class="app-content-header">
                <h2>Edit Data Dokter</h2>
            </header>
            <form action="edit_dokter.php?id=<?php echo htmlspecialchars($id_dokter); ?>" method="post">
                <label for="nama_dokter">Nama dokter:</label> <label for="nama_dokter"></label>
                <input type="text" id="nama_dokter" name="nama_dokter"
                    value="<?php echo htmlspecialchars($dokter['nama_dokter']); ?>" required>

                <label for="spesialisasi">spesialisasi:</label>
                <input type="text" id="spesialisasi" name="spesialisasi" value="<?php echo htmlspecialchars($dokter['spesialisasi']); ?>"
                    required>

                <label for="nomor_telepon">Nomor Telepon:</label>
                <input type="text" id="nomor_telepon" name="nomor_telepon"
                    value="<?php echo htmlspecialchars($dokter['nomor_telepon']); ?>" required>

                <label for="jadwal_praktik">Jadwal Praktik:</label>
                <input type="text" id="jadwal_praktik" name="jadwal_praktik"
                value="<?php echo htmlspecialchars($dokter['jadwal_praktik']); ?>" required>

                <label for="email">Email:</label>
                <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($dokter['email']); ?>"
                required>

                <input type="submit" value="Simpan Perubahan">
            </form>
        </div>
    </div>
</body>

</html>