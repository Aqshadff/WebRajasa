<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran yang sesuai
if (!isset($_SESSION['username']) || ($_SESSION['role'] !== 'Admin' && $_SESSION['role'] !== 'Dokter')) {
    header("Location: login.php");
    exit();
}

// Ambil ID rekam medis dari query parameter
$id_rekam_medis = isset($_GET['id_rekam_medis']) ? $_GET['id_rekam_medis'] : 0;

// Ambil data rekam medis berdasarkan ID
$sql = "SELECT * FROM rekam_medis WHERE id_rekam_medis = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_rekam_medis);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

// Pastikan data tidak null
if (!$data) {
    echo "Data rekam medis tidak ditemukan.";
    exit();
}

// Ambil data pasien, dokter, dan obat untuk dropdown
$pasien_result = $conn->query("SELECT id_pasien, nama_pasien FROM pasien");
$dokter_result = $conn->query("SELECT id_dokter, nama_dokter FROM dokter");
$obat_result = $conn->query("SELECT id_obat, nama_obat FROM obat");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pasien = $_POST['id_pasien'];
    $id_dokter = $_POST['id_dokter'];
    $tanggal_kunjungan = $_POST['tanggal_kunjungan'];
    $diagnosa = $_POST['diagnosa'];
    $tindakan = $_POST['tindakan'];
    $resep_obat = $_POST['resep_obat'];
    $catatan = $_POST['catatan'];
    $alergi = $_POST['alergi'];
    $status_kunjungan = $_POST['status_kunjungan'];

    // Update rekam medis
    $sql = "UPDATE rekam_medis SET id_pasien = ?, id_dokter = ?, tanggal_kunjungan = ?, diagnosa = ?, tindakan = ?, resep_obat = ?, catatan = ?, alergi = ?, status_kunjungan = ? WHERE id_rekam_medis = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssi", $id_pasien, $id_dokter, $tanggal_kunjungan, $diagnosa, $tindakan, $resep_obat, $catatan, $alergi, $status_kunjungan, $id_rekam_medis);

    if ($stmt->execute()) {
        // Catat perubahan ke tabel history
        $perubahan = "Diubah oleh " . $_SESSION['username'] . " pada " . date("Y-m-d H:i:s");
        $history_sql = "INSERT INTO rekam_medis_history (id_rekam_medis, perubahan) VALUES (?, ?)";
        $history_stmt = $conn->prepare($history_sql);
        $history_stmt->bind_param("is", $id_rekam_medis, $perubahan);
        $history_stmt->execute();
        
        header("Location: kelola_rekam_medis.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Rekam Medis</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item active">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
        </aside>
        <main class="app-content">
            <header class="app-content-header">
                <h2>Edit Rekam Medis</h2>
            </header>
            <div class="app-content-body">
                <form action="kelola_rekam_medis.php" method="POST">
                    <div class="mb-3">
                        <label for="id_pasien" class="form-label">Pasien</label>
                        <select class="form-select" id="id_pasien" name="id_pasien" required>
                            <option value="">Pilih Pasien</option>
                            <?php
                            while ($row = $pasien_result->fetch_assoc()) {
                                $selected = $row['id_pasien'] == $data['id_pasien'] ? 'selected' : '';
                                echo "<option value='" . $row['id_pasien'] . "' $selected>" . htmlspecialchars($row['nama_pasien']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="id_dokter" class="form-label">Dokter</label>
                        <select class="form-select" id="id_dokter" name="id_dokter" required>
                            <option value="">Pilih Dokter</option>
                            <?php
                            while ($row = $dokter_result->fetch_assoc()) {
                                $selected = $row['id_dokter'] == $data['id_dokter'] ? 'selected' : '';
                                echo "<option value='" . $row['id_dokter'] . "' $selected>" . htmlspecialchars($row['nama_dokter']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tanggal_kunjungan" class="form-label">Tanggal Kunjungan</label>
                        <input type="date" class="form-control" id="tanggal_kunjungan" name="tanggal_kunjungan" value="<?php echo htmlspecialchars($data['tanggal_kunjungan']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="diagnosa" class="form-label">Diagnosa</label>
                        <textarea class="form-control" id="diagnosa" name="diagnosa" rows="3" required><?php echo htmlspecialchars($data['diagnosa']); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="tindakan" class="form-label">Tindakan</label>
                        <textarea class="form-control" id="tindakan" name="tindakan" rows="3" required><?php echo htmlspecialchars($data['tindakan']); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="resep_obat" class="form-label">Resep Obat</label>
                        <select class="form-select" id="resep_obat" name="resep_obat" required>
                            <option value="">Pilih Obat</option>
                            <?php
                            while ($row = $obat_result->fetch_assoc()) {
                                $selected = $row['id_obat'] == $data['resep_obat'] ? 'selected' : '';
                                echo "<option value='" . $row['id_obat'] . "' $selected>" . htmlspecialchars($row['nama_obat']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="catatan" class="form-label">Catatan</label>
                        <textarea class="form-control" id="catatan" name="catatan" rows="3" required><?php echo htmlspecialchars($data['catatan']); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="alergi" class="form-label">Alergi</label>
                        <input type="text" class="form-control" id="alergi" name="alergi" value="<?php echo htmlspecialchars($data['alergi']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="status_kunjungan" class="form-label">Status Kunjungan</label>
                        <select class="form-select" id="status_kunjungan" name="status_kunjungan" required>
                            <option value="Selesai" <?php echo $data['status_kunjungan'] == 'Selesai' ? 'selected' : ''; ?>>Selesai</option>
                            <option value="Menunggu" <?php echo $data['status_kunjungan'] == 'Menunggu' ? 'selected' : ''; ?>>Menunggu</option>
                            <option value="Dibatalkan" <?php echo $data['status_kunjungan'] == 'Dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </main>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
