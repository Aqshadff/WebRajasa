<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses form ketika dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_obat = $_POST['nama_obat'];
    $jenis_obat = $_POST['jenis_obat'];
    $stok = $_POST['stok'];
    $harga = $_POST['harga'];

    $sql = "INSERT INTO obat (nama_obat, jenis_obat, stok, harga)
            VALUES ('$nama_obat', '$jenis_obat', '$stok', '$harga')";

    if ($conn->query($sql) === TRUE) {
        header("Location: kelola_obat.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah obat</title>
    <link rel="stylesheet" href="../css/styles12.css"> <!-- Pastikan Anda punya file styles.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>

<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
            <ul class="sidebar-list">
                <li class="sidebar-item active">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
            <div class="account-info">
                
            
            </div>
        </aside>

        <!-- Konten Utama -->
        <main class="app-content">
            <header class="app-content-header">
                <h2>Tambah obat</h2>
            </header>
            <div class="app-content-body">
                <form action="proses_tambah_obat.php" method="post">
                    <div class="mb-3">
                        <label for="nama_obat" class="form-label">Nama obat</label>
                        <input type="text" id="nama_obat" name="nama_obat" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="jenis_obat" class="form-label">Jenis Obat</label>
                        <input type="text" id="jenis_obat" name="jenis_obat" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="stok" class="form-label">Stok</label>
                        <input type="text" id="stok" name="stok" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="harga" class="form-label">Harga</label>
                        <input type="decimal" id="harga" name="harga" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </main>
    </div>

    <!-- JavaScript for Bootstrap -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
$conn->close();
?>