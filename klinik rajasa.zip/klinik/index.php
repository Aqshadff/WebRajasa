<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Klinik Sehat</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Tambahkan link font-awesome -->
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #fff, #343a40);
            overflow-x: hidden;
            /* Menghindari scroll horizontal */
        }

        header {
            background: linear-gradient(90deg, #343a40, #00aaff);
            color: #fff;
            padding: 1rem 0;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }

        header:hover {
            background: linear-gradient(90deg, #0056b3, #007bff);
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: auto;
            padding: 0 1rem;
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #fff;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
            transition: color 0.3s ease;
        }

        .navbar-brand:hover {
            color: #d1e7fd;
        }

        .navbar-nav {
            display: flex;
            gap: 1.5rem;
        }

        .navbar-nav a {
            color: #fff;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s;
            position: relative;
        }

        .navbar-nav a::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 2px;
            background: #fff;
            transition: width 0.3s, left 0.3s;
        }

        .navbar-nav a:hover::after {
            width: 100%;
            left: 0;
        }

        .navbar-nav a:hover {
            background-color: #0056b3;
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .login-btn {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s;
        }

        .login-btn:hover {
            background-color: #218838;
            transform: scale(1.05);
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            padding: 1rem;
            margin-top: 4rem;
            /* Offset for fixed header */
        }

        h1,
        h2,
        h3 {
            color: #007bff;
            transition: color 0.3s, transform 0.3s;
            text-align: center;
        }

        h1:hover,
        h2:hover,
        h3:hover {
            color: # transform: scale(1.05);
        }


        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .section {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            padding: 1rem;
            transition: box-shadow 0.3s, transform 0.3s;
            animation: fadeIn 1s ease-in-out;
        }

        .section:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transform: translateY(-5px);
        }

        .team-member {
            margin-bottom: 1rem;
            border-left: 4px solid #007bff;
            padding-left: 1rem;
            transition: border-color 0.3s, transform 0.3s;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .team-member img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .team-member img:hover {
            transform: scale(1.1);
        }

        .team-member:hover {
            border-color: #0056b3;
            transform: scale(1.02);
        }

        .contact-info {
            background: #fff;
            padding: 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: left;
        }

        .contact-info a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s;
        }

        .contact-info a:hover {
            color: #0056b3;
        }

        footer {
    background-color: #343a40;
    padding: 40px 0;
    color: #fff;
}

.footer-top {
    background-color: #343a40;
    color: #fff;
    padding: 3px;
}

.footer-content {
    text-align: center;
}

.footer-content p {
    margin: 0;
    font-size: 14px;
}

.footer-content a {
    color: #007bff;
    text-decoration: none;
}

.footer-content a:hover {
    text-decoration: underline;
}

.social-media {
    margin-top: 10px;
}

.social-media a {
    color: #fff;
    font-size: 18px;
    margin: 0 10px;
    transition: color 0.3s;
}

.social-media a:hover {
    color: #007bff;
}

.footer-area {
    padding: 1px 0;
}

.single-footer-widget {
    margin-bottom: 30px;
}

.single-footer-widget h3 {
    margin-bottom: 20px;
    color: #fff;
}

.single-footer-widget ul {
    list-style: none;
    padding: 0;
}

.single-footer-widget ul li {
    margin-bottom: 10px;
}

.single-footer-widget ul li a {
    color: #007bff;
    text-decoration: none;
}

.single-footer-widget ul li a:hover {
    text-decoration: underline;
}

.social {
    list-style: none;
    padding: 0;
    display: flex;
}

.social li {
    margin: 0 10px;
}

.social a {
    color: #fff;
    font-size: 20px;
}

.social a:hover {
    color: #007bff;
}

.footer-area .copyright-area {
    text-align: center;
    padding: 20px 0;
    background-color: #ffff;
    color: #fff;
}

.footer-area .copyright-area p {
    margin: 0;
    font-size: 14px;
}


        .social-media {
            margin-top: 1rem;
        }

        .social-media a {
            color: #fff;
            text-decoration: none;
            margin: 0 0.5rem;
            font-size: 1.5rem;
            transition: color 0.3s;
        }

        .social-media a:hover {
            color: #007bff;
        }

        /* Optional: Add spacing between icons */
        .social-media a+a {
            margin-left: 0.5rem;
        }


        /* Mobile Styles */
        @media (max-width: 768px) {
            .navbar-nav {
                display: none;
                flex-direction: column;
                background-color: #007bff;
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                transition: max-height 0.3s ease;
                max-height: 0;
                overflow: hidden;
            }

            .navbar-nav.active {
                display: flex;
                max-height: 500px;
                /* Ensure the dropdown is visible */
            }

            .navbar-toggler {
                display: block;
                background-color: #fff;
                border: none;
                padding: 0.5rem 1rem;
                color: #007bff;
                font-size: 1.5rem;
                cursor: pointer;
                transition: background-color 0.3s;
            }

            .navbar-toggler:hover {
                background-color: #f1f1f1;
            }
        }

        /* Style for Doctor Images */
        .doctor-image {
            border-radius: 50%;
            width: 80px;
            height: 80px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .doctor-image:hover {
            transform: scale(1.1);
        }

        .login-btn {
            background-color: #218838;
            color: #fff;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s;
            transform: 0.3s;
            box-shadow: 0.3s;
        }

        .login-btn:hover {
            background-color: #218838;
            transform: scale(1.05);
            box-shadow: 0.4px 8px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>

<body>

    <header>
        <div class="navbar">
            <div class="navbar-brand">Klinik Sehat</div>
            <button class="navbar-toggler" aria-label="Toggle navigation">&#9776;</button>
            <div class="navbar-nav">
                <a href="index.php"><i class="fas fa-home"></i> Beranda</a>
                <a href="services.php"><i class="fas fa-cogs"></i> Layanan</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="jadwal_dokter.php"><i class="fas fa-calendar-day"></i> Jadwal Dokter</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact Me</a>
                <a href="login.php" class="login-btn"><i class="fas fa-sign-in-alt"></i> Login</a>
            </div>
        </div>
    </header>

    <div class="container">
        <section id="home" class="section">
            <h2>Selamat Datang di Klinik Sehat</h2>
            <p>Di Klinik Sehat, kami percaya bahwa kesehatan adalah aset yang paling berharga. Kami berdedikasi untuk
                memberikan layanan medis berkualitas tinggi dengan pendekatan yang ramah dan penuh perhatian. Tim kami
                yang terdiri dari dokter dan tenaga medis berpengalaman siap membantu Anda mencapai kesehatan yang
                optimal.</p>
        </section>
        <div class="section">
            <h2>Berita Terbaru</h2>
            <div class="news-item">
                <img src="berita1.jpg" alt="Berita 1"> 
                <div>
                    <h3>Pengumuman Klinik Sehat Terbaru</h3>
                    <p>Klinik Sehat akan mengadakan seminar kesehatan pada tanggal 15 September 2024. Ayo daftar
                        sekarang!</p>
                </div>
            </div>
            <div class="news-item">
                <img src="diet.jpg" alt="Berita 2">
                <div>
                    <h3>Pelayanan Baru di Klinik Sehat</h3>
                    <p>Kami dengan bangga mengumumkan bahwa Klinik Sehat kini menyediakan layanan konsultasi gizi dan
                        diet.</p>
                </div>
            </div>
            <!-- Tambahkan lebih banyak berita sesuai kebutuhan -->
        </div>

        <section id="services" class="section">
            <h2>Visi Kami</h2>
            <p>Menjadi pusat kesehatan terkemuka yang dikenal karena keunggulan dalam perawatan pasien, inovasi medis,
                dan layanan yang penuh empati. Kami berkomitmen untuk meningkatkan kualitas hidup komunitas melalui
                pelayanan kesehatan yang komprehensif dan terpercaya.</p>
        </section>

        <section id="about" class="section">
            <h2>Misi Kami</h2>
            <ul>
                <li>Memberikan Pelayanan Terbaik: Menyediakan layanan medis dengan standar tinggi dan teknologi terkini.
                </li>
                <li>Mengedepankan Kepuasan Pasien: Mengutamakan kepuasan pasien melalui pendekatan yang personal dan
                    perhatian terhadap detail.</li>
                <li>Inovasi dan Pendidikan: Mengadopsi praktik medis terbaru dan berinvestasi dalam pendidikan serta
                    pelatihan staf.</li>
            </ul>
        </section>

        <section id="contact" class="section">
            <h2>Layanan Kami</h2>
            <ul>
                <li>Konsultasi Medis Umum</li>
                <li>Perawatan Spesialis</li>
                <li>Layanan Laboratorium</li>
                <li>Layanan Radiologi</li>
                <li>Perawatan Darurat</li>
                <li>Pemeriksaan Kesehatan Berkala</li>
                <li>Vaksinasi dan Imunisasi</li>
                <li>Rehabilitasi dan Terapi Fisik</li>
            </ul>
        </section>

        <section id="team" class="section">
            <h2>Tim Kami</h2>
            <div class="team-member">
                <img src="ana.jpg" alt="Dr. Ana Putri" class="doctor-image">
                <div>
                    <h3>Dr. Ana Putri, Sp.KK</h3>
                    <p>Dokter Spesialis Kulit dan Kelamin</p>
                </div>
            </div>
            <div class="team-member">
                <img src="budi.jpeg" alt="Dr. Budi Santoso" class="doctor-image">
                <div>
                    <h3>Dr. Budi Santoso, Sp.P</h3>
                    <p>Dokter Spesialis Paru</p>
                </div>
            </div>
            <div class="team-member">
                <img src="clara1.jpeg" alt="Dr. Clara Yuliana" class="doctor-image">
                <div>
                    <h3>Dr. Clara Yuliana, Sp.A</h3>
                    <p>Dokter Spesialis Anak</p>
                </div>
            </div>
            <p>Tim Perawat dan Staf Medis: Kompeten, berpengalaman, dan selalu siap membantu</p>
        </section>

        <section id="facilities" class="section">
            <h2>Fasilitas Kami</h2>
            <ul>
                <li>Ruang Pemeriksaan</li>
                <li>Laboratorium Terintegrasi</li>
                <li>Ruang Radiologi</li>
                <li>Area Tunggu Nyaman</li>
                <li>Kantin Kesehatan</li>
            </ul>
        </section>

        <section id="hours" class="section">
            <h2>Jam Operasional</h2>
            <p><strong>Senin - Jumat:</strong> 08:00 - 17:00</p>
            <p><strong>Sabtu:</strong> 09:00 - 14:00</p>
            <p><strong>Minggu:</strong> Tutup</p>
        </section>

        <section id="contact" class="section contact-info">
            <h2>Lokasi Kami</h2>
            <p><strong>Klinik Sehat</strong></p>
            <p>Jl. Kesehatan No. 123</p>
            <p>Kota Sejahtera, 45678</p>
            <p>Telepon: <a href="tel:(021)123-4567">(021) 123-4567</a></p>
            <p>Email: <a href="mailto:info@kliniksehat.com">info@kliniksehat.com</a></p>
        </section>

        <section id="contact" class="section">
            <h2>Hubungi Kami</h2>
            <p>Jika Anda memiliki pertanyaan atau ingin membuat janji, jangan ragu untuk menghubungi kami melalui:</p>
            <p>Telepon: <a href="tel:(021)123-4567">(021) 123-4567</a></p>
            <p>Email: <a href="mailto:info@kliniksehat.com">info@kliniksehat.com</a></p>
            <p>Formulir Kontak: <a href="#">Link ke formulir kontak</a></p>
        </section>

        <section id="testimonials" class="section">
            <h2>Testimoni Pasien</h2>
            <blockquote>
                <p>"Klinik Sehat menyediakan pelayanan yang luar biasa. Stafnya ramah dan profesional. Saya merasa
                    sangat diperhatikan dan puas dengan layanan yang diberikan." – Rina S.</p>
            </blockquote>
        </section>

        <section id="news" class="section">
            <h2>Berita Terbaru</h2>
            <p>Tetap update dengan berita terbaru dan tips kesehatan melalui blog kami dan media sosial:</p>
            <p>Blog Kesehatan: <a href="#">Link ke blog</a></p>
            <p>Facebook: <a href="#">Link ke Facebook</a></p>
            <p>Instagram: <a href="#">Link ke Instagram</a></p>
        </section>

        <section id="safety" class="section">
            <h2>Komitmen Kami pada Keselamatan</h2>
            <p>Kami menerapkan protokol kesehatan dan keselamatan yang ketat untuk memastikan lingkungan yang aman bagi
                pasien dan staf. Kami mengikuti panduan terbaru dari otoritas kesehatan dan memastikan kebersihan serta
                sanitasi di seluruh area klinik.</p>
        </section>
    </div>

    <footer>
    <div class="footer-top">
        <div class="footer-content">
            <p>&copy; 2024 Klinik Sehat. Semua hak dilindungi. | <a href="#">Kebijakan Privasi</a> | <a href="#">Syarat dan Ketentuan</a></p>
            <div class="social-media">
                <a href="https://facebook.com/kliniksehat" target="_blank" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com/kliniksehat" target="_blank" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                <a href="https://instagram.com/kliniksehat" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="https://tiktok.com/@kliniksehat" target="_blank" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
            </div>
        </div>
    </div>
    <section class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="single-footer-widget">
                        <div class="logo">
                            <a href="/id"><img src="rs.jpeg" alt="Logo" width="65"></a>
                        </div>
                        <p><b>klinik sehat Center: 1500-488</b></p>
                        <p>Layanan Pengaduan Konsumen:</p>
                        <p>Direktorat Jendral Perlindungan Konsumen dan Tertib Niaga Kementerian Perdagangan Republik Indonesia.</p>
                        <p>WhatsApp: <a href="https://wa.me/6281573635413" target="_blank">0815-7363-5413</a>.</p>
                        <ul class="social">
                            <li><a href="https://www.facebook.com/RSHermina" target="_blank"><i class="fab fa-facebook"></i></a></li>
                            <li><a href="https://www.instagram.com/herminahospitals/" target="_blank"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="https://www.youtube.com/channel/UCivSGRvIBr10aPuVrSARkTA" target="_blank"><i class="fab fa-youtube"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-footer-widget">
                        <h3>Klinik sehat</h3>
                        <ul class="departments-list">
                            <li><a href="/id/pages/visi-misi">Tentang Kami</a></li>
                            <li><a href="/id/corporate-milestones">Tonggak Sejarah Perusahaan</a></li>
                            <li><a href="/id/managements">Manajemen Kami</a></li>
                            <li><a href="/id/awards">Penghargaan</a></li>
                            <li><a href="/id/academics">Pendidikan dan Pelatihan</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-footer-widget">
                        <h3>Perusahaan</h3>
                        <ul class="links-list">
                            <li><a href="/id/pages/business-overview">Tinjauan Bisnis</a></li>
                            <li><a href="/id/press-releases">Berita Terkini</a></li>
                            <li><a href="/id/corporate-publications?tab=corporate_presentations">Publikasi Perusahaan</a></li>
                            <li><a href="/id/financial-statements">Ikhtisar Keuangan</a></li>
                            <li><a href="/id/analyst-coverages">Liputan Analis</a></li>
                            <li><a href="/id/environmental-governance">Environmental Social Governance</a></li>
                            <li><a href="/id/pages/csr">Tanggung Jawab Sosial Perusahaan</a></li>
                            <li><a href="/id/pages/business-opportunity">Peluang Bisnis</a></li>
                            <li><a href="/id/investor-relations-contacts">Kontak Hubungan Investor</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-footer-widget">
                        <h3>Bergabung</h3>
                        <ul class="links-list">
                            <li><a href="/id/careers">Karir</a></li>
                        </ul>
                    </div>
                </div>
            </div>
         </div>
    </section>
</footer>


    <script>
        document.querySelector('.navbar-toggler').addEventListener('click', function () {
            const navbarNav = document.querySelector('.navbar-nav');
            navbarNav.classList.toggle('active');

            // Animate the transition for smoother appearance
            if (navbarNav.classList.contains('active')) {
                navbarNav.style.maxHeight = ${ navbarNav.scrollHeight } px;
            } else {
                navbarNav.style.maxHeight = '0';
            }
        });
    </script>

</body>

</html>