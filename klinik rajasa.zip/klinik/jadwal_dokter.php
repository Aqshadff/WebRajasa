<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Dokter - Klinik Sehat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
            background: #f0f2f5;
        }
        header {
            background: linear-gradient(90deg, #007bff, #00aaff);
            color: #fff;
            padding: 1rem 0;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }

        header:hover {
            background: linear-gradient(90deg, #0056b3, #007bff);
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: auto;
            padding: 0 1rem;
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #fff;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
            transition: color 0.3s ease;
        }

        .navbar-brand:hover {
            color: #d1e7fd;
        }

        .navbar-nav {
            display: flex;
            gap: 1.5rem;
        }

        .navbar-nav a {
            color: #fff;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s;
            position: relative;
        }

        .navbar-nav a::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 2px;
            background: #fff;
            transition: width 0.3s, left 0.3s;
        }

        .navbar-nav a:hover::after {
            width: 100%;
            left: 0;
        }

        .navbar-nav a:hover {
            background-color: #0056b3;
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .login-btn {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s;
        }

        .login-btn:hover {
            background-color: #218838;
            transform: scale(1.05);
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: auto;
            padding: 2rem;
        }

        .text-spesialis {
            font-size: 1.5rem;
            color: #007bff;
            margin: 1rem 0;
        }

        hr {
            border: 0;
            border-top: 1px solid #ddd;
            margin: 1rem 0;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -1rem;
        }

        .col-lg-2, .col-lg-10, .col-md-6, .col-sm-2, .col-4, .col-12 {
            padding: 0 1rem;
            box-sizing: border-box;
        }

        .col-lg-2 {
            flex: 0 0 16.6667%;
            max-width: 16.6667%;
        }

        .col-lg-10 {
            flex: 0 0 83.3333%;
            max-width: 83.3333%;
        }

        .col-md-6 {
            flex: 0 0 50%;
            max-width: 50%;
        }

        .col-sm-2 {
            flex: 0 0 16.6667%;
            max-width: 16.6667%;
        }

        .col-4 {
            flex: 0 0 33.3333%;
            max-width: 33.3333%;
        }

        .col-12 {
            flex: 0 0 100%;
            max-width: 100%;
        }

        .v-image {
            position: relative;
            overflow: hidden;
            border-radius: 50%;
            height: 100px;
            width: 100px;
        }

        .v-image__image {
            background-size: cover;
            background-position: center;
            height: 100%;
            width: 100%;
        }

        .text-nama-dokter {
            font-size: 1.2rem;
            color: #333;
            margin: 0;
        }

        .text-rs {
            margin: 0;
            color: #666;
        }

        .btn-appointment {
            margin-top: 0.5rem;
            background-color: #007bff;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.875rem;
            text-align: center;
        }

        .btn-appointment:hover {
            background-color: #0056b3;
        }

        .v-data-table {
            margin-top: 1rem;
        }

        .v-data-table__wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ddd;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 0.5rem;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tbody tr:hover {
            background-color: #f1f1f1;
        }

        /* Footer Styles */
        .footer {
            background-color: #007bff;
            color: white;
            padding: 2rem 0;
            margin-top: 2rem;
        }

        .footer .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .footer h5 {
            margin-bottom: 1rem;
            font-size: 1.2rem;
        }

        .footer a {
            color: white;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .footer .column {
            flex: 1;
            margin: 0 1rem;
        }

        .footer .social-icons {
            display: flex;
            list-style: none;
            padding: 0;
            margin: 1rem 0 0;
        }

        .footer .social-icons li {
            margin-right: 1rem;
        }

        .footer .social-icons a {
            color: white;
            font-size: 1.5rem;
            text-decoration: none;
        }

        .footer .social-icons a:hover {
            color: #ccc;
        }

        .footer .contact-info, .footer .quick-links {
            margin-bottom: 1rem;
        }

        .footer .contact-info p, .footer .quick-links ul {
            margin: 0;
        }

        .footer .quick-links ul {
            list-style: none;
            padding: 0;
        }

        .footer .quick-links ul li {
            margin-bottom: 0.5rem;
        }
    </style>
</head>
<body>
<header>
    <div class="navbar">
        <div class="navbar-brand">Klinik Sehat</div>
        <button class="navbar-toggler" aria-label="Toggle navigation">&#9776;</button>
        <div class="navbar-nav">
            <a href="index.php">Beranda</a>
            <a href="services.php">Layanan</a>
            <a href="about.php">About</a>
            <a href="jadwal_dokter.php">Jadwal Dokter</a>
            <a href="contact.php">Contact Me</a>
            <a href="login.php" class="login-btn">Login</a>
        </div>
    </div>
</header>

<div class="container">
    <h3 class="text-spesialis">Saraf</h3>
    <hr>
    
    <!-- Dokter 1 -->
    <div class="row">
        <div class="col-lg-2 col-md-6 col-sm-2 col-4">
            <div class="v-image">
                <div class="v-image__image" style="background-image: url('https://cdn.liramedika.com/get/liracare/uploads/dokter/ZswRb1bVjp5SSzz05qDqspc4R09X5z.jpg');"></div>
            </div>
        </div>
        <div class="col-lg-10 col-sm-10 col-12">
            <h5 class="text-nama-dokter">dr. Eny Nurhayati, Sp.S</h5>
            <p class="text-rs">
                Lira Medika Karawang &nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="/dokter/dr-eny-nurhayati-sps">Profile</a>
            </p>
            <button type="button" class="btn-appointment">
                Appointment
            </button>
            <div class="v-data-table">
                <div class="v-data-table__wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Senin</th>
                                <th>Selasa</th>
                                <th>Rabu</th>
                                <th>Kamis</th>
                                <th>Jumat</th>
                                <th>Sabtu</th>
                                <th>Minggu</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>14:00 - 16:00</td>
                                <td>11:00 - 14:00</td>
                                <td>14:00 - 16:00</td>
                                <td>11:00 - 14:00</td>
                                <td>12:00 - 13:00</td>
                                <td>09:30 - 12:00</td>
                                <td>-</td>
                            </tr>
                            <tr>
                                <td>11:00 - 14:00</td>
                                <td>14:00 - 16:00</td>
                                <td>11:00 - 14:00</td>
                                <td>14:00 - 16:00</td>
                                <td>11:00 - 12:00</td>
                                <td>07:30 - 09:30</td>
                                <td>-</td>
                            </tr>
                            <tr>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>07:30 - 09:30</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                            <tr>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>09:30 - 11:00</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Dokter 2 -->
    <div class="row">
        <div class="col-lg-2 col-md-6 col-sm-2 col-4">
            <div class="v-image">
                <div class="v-image__image" style="background-image: url('https://cdn.liramedika.com/get/liracare/uploads/dokter/vxCMp4Dksh2aYUT0sl3DIn3JEytv8K.jpg');"></div>
            </div>
        </div>
        <div class="col-lg-10 col-sm-10 col-12">
            <h5 class="text-nama-dokter">dr. Yovita Stevina S Sp.S</h5>
            <p class="text-rs">
                Lira Medika Karawang &nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="/dokter/dr-yovita-stevina-s-sp-s">Profile</a>
            </p>
            <button type="button" class="btn-appointment">
                Appointment
            </button>
            <div class="v-data-table">
                <div class="v-data-table__wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Senin</th>
                                <th>Selasa</th>
                                <th>Rabu</th>
                                <th>Kamis</th>
                                <th>Jumat</th>
                                <th>Sabtu</th>
                                <th>Minggu</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>19:00 - 20:00</td>
                                <td>-</td>
                                <td>19:00 - 20:00</td>
                                <td>-</td>
                                <td>10:00 - 11:00</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                            <tr>
                                <td>-</td>
                                <td>15:00 - 18:00</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>09:00 - 11:00</td>
                            </tr>
                            <tr>
                                <td>09:00 - 11:00</td>
                                <td>-</td>
                                <td>10:00 - 12:00</td>
                                <td>-</td>
                                <td>19:00 - 21:00</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                            <tr>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>10:00 - 12:00</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <div class="column contact-info">
            <h5>Kontak Kami</h5>
            <p>Jl. Sehat No. 1, Karawang</p>
            <p>Telepon: (0267) 123456</p>
            <p>Email: info@kliniksehat.com</p>
        </div>
        <div class="column quick-links">
            <h5>Link Cepat</h5>
            <ul>
                <li><a href="/">Beranda</a></li>
                <li><a href="/jadwal-dokter">Jadwal Dokter</a></li>
                <li><a href="/kontak">Kontak</a></li>
                <li><a href="/tentang-kami">Tentang Kami</a></li>
            </ul>
        </div>
        <div class="column social-media">
            <h5>Ikuti Kami</h5>
            <ul class="social-icons">
                <li><a href="https://facebook.com" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="https://twitter.com" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
                <li><a href="https://instagram.com" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>
                <li><a href="https://linkedin.com" target="_blank" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a></li>
            </ul>
        </div>
    </div>
</footer>

<!-- Font Awesome for social icons -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>

</body>
</html>
