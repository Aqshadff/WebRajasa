<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk mengambil data laporan
function getLaporan($conn, $query) {
    $result = $conn->query($query);
    if ($result === FALSE) {
        return []; // Mengembalikan array kosong jika query gagal
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Query untuk laporan kunjungan pasien
$query_kunjungan = "SELECT tanggal_kunjungan, COUNT(*) as jumlah_kunjungan FROM rekam_medis GROUP BY tanggal_kunjungan";
$laporan_kunjungan = getLaporan($conn, $query_kunjungan);

// Query untuk laporan dokter
$query_dokter = "SELECT * FROM dokter";
$laporan_dokter = getLaporan($conn, $query_dokter);

// Query untuk laporan obat
$query_obat = "SELECT nama_obat, COUNT(*) as jumlah FROM obat GROUP BY nama_obat";
$laporan_obat = getLaporan($conn, $query_obat);

// Query untuk laporan penjualan obat
$query_penjualan = "SELECT nama_obat, SUM(jumlah_terjual) as total_terjual, SUM(jumlah_terjual * harga_satuan) as total_harga, tanggal_penjualan FROM penjualan_obat GROUP BY nama_obat";
$laporan_penjualan = getLaporan($conn, $query_penjualan);

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan - Admin Panel</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item active">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <h2>Laporan</h2>
            </header>
            <div class="app-content-body">
                <!-- Tombol Unduh CSV -->
                <form method="POST" action="export_rekam_medis.php" style="margin-bottom: 20px;">
                    <button type="submit" class="btn btn-secondary">Unduh CSV <i class="fas fa-file-csv"></i></button>
                </form>

                <!-- Laporan Kunjungan Pasien -->
                <div class="report-section">
                    <h3>Laporan Kunjungan Pasien</h3>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Tanggal Kunjungan</th>
                                <th>Jumlah Kunjungan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($laporan_kunjungan)): ?>
                                <?php foreach ($laporan_kunjungan as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['tanggal_kunjungan']); ?></td>
                                        <td><?php echo htmlspecialchars($row['jumlah_kunjungan']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="2">Tidak ada data.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Laporan Dokter -->
                <div class="report-section">
                    <h3>Laporan Dokter</h3>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID Dokter</th>
                                <th>Nama Dokter</th>
                                <th>Spesialisasi</th>
                                <th>Nomor Telepon</th>
                                <th>Email</th>
                                <th>Jadwal Praktik</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($laporan_dokter)): ?>
                                <?php foreach ($laporan_dokter as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['id_dokter']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_dokter']); ?></td>
                                        <td><?php echo htmlspecialchars($row['spesialisasi']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nomor_telepon']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['jadwal_praktik']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6">Tidak ada data.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Laporan Obat -->
                <div class="report-section">
                    <h3>Laporan Obat</h3>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nama Obat</th>
                                <th>Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($laporan_obat)): ?>
                                <?php foreach ($laporan_obat as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['nama_obat']); ?></td>
                                        <td><?php echo htmlspecialchars($row['jumlah']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="2">Tidak ada data.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Laporan Penjualan Obat -->
                <div class="report-section">
                    <h3>Laporan Penjualan Obat</h3>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nama Obat</th>
                                <th>Total Terjual</th>
                                <th>Total Harga</th>
                                <th>Tanggal Penjualan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($laporan_penjualan)): ?>
                                <?php foreach ($laporan_penjualan as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['nama_obat']); ?></td>
                                        <td><?php echo htmlspecialchars($row['total_terjual']); ?></td>
                                        <td><?php echo number_format(htmlspecialchars($row['total_harga']), 2); ?></td>
                                        <td><?php echo htmlspecialchars($row['tanggal_penjualan']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4">Tidak ada data.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
