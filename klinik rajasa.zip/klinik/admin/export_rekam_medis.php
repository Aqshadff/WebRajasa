<?php
session_start();

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klinik_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengatur header untuk file CSV
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="rekam_medis.csv"');

// Membuka file output untuk penulisan CSV
$output = fopen('php://output', 'w');

// Menulis header CSV
fputcsv($output, ['ID Rekam Medis', 'Nama Pasien', 'Nama Dokter', 'Tanggal Kunjungan', 'Diagnosa', 'Tindakan', 'Resep Obat', 'Catatan', 'Alergi']);

// Query untuk mendapatkan data rekam medis
$sql = "SELECT rekam_medis.*, pasien.nama_pasien, dokter.nama_dokter
        FROM rekam_medis
        JOIN pasien ON rekam_medis.id_pasien = pasien.id_pasien
        JOIN dokter ON rekam_medis.id_dokter = dokter.id_dokter";
$result = $conn->query($sql);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        // Menulis data ke dalam file CSV
        fputcsv($output, [
            $row['id_rekam_medis'],
            $row['nama_pasien'],
            $row['nama_dokter'],
            $row['tanggal_kunjungan'],
            $row['diagnosa'],
            $row['tindakan'],
            $row['resep_obat'],
            $row['catatan'],
            $row['alergi']
        ]);
    }
} else {
    echo "Query Error: " . $conn->error;
}

// Menutup file output
fclose($output);
exit();
?>
