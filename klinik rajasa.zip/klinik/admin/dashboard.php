<?php
session_start();
if (!isset($_SESSION['username']) ||  ($_SESSION['role']!== 'Admin')) {
    echo "<a href='login.php'>Login</a>";
    exit();
}


// Koneksi ke database
include 'koneksi.php';
// Hitung jumlah pasien
$sql = "SELECT COUNT(*) AS total_pasien FROM pasien";
$result = $conn->query($sql);
if ($result) {
    $total_pasien = $result->fetch_assoc()['total_pasien'];
} else {
    die("Query gagal: " . $conn->error);
}

// Hitung jumlah dokter
$sql = "SELECT COUNT(*) AS total_dokter FROM dokter";
$result = $conn->query($sql);
if ($result) {
    $total_dokter = $result->fetch_assoc()['total_dokter'];
} else {
    die("Query gagal: " . $conn->error);
}

// Hitung jumlah kunjungan hari ini
$sql = "SELECT COUNT(*) AS kunjungan_hari_ini FROM rekam_medis WHERE tanggal_kunjungan = CURDATE()";
$result = $conn->query($sql);
if ($result) {
    $kunjungan_hari_ini = $result->fetch_assoc()['kunjungan_hari_ini'];
} else {
    die("Query gagal: " . $conn->error);
}

// Hitung total ruangan yang tersedia
$sql = "SELECT COUNT(*) AS total_ruangan FROM ruang WHERE status = 'Tersedia'";
$result = $conn->query($sql);
if ($result) {
    $total_ruangan = $result->fetch_assoc()['total_ruangan'];
} else {
    die("Query gagal: " . $conn->error);
}

// Hitung jumlah rekam medis
$sql = "SELECT COUNT(*) AS total_rekam_medis FROM rekam_medis";
$result = $conn->query($sql);
if ($result) {
    $total_rekam_medis = $result->fetch_assoc()['total_rekam_medis'];
} else {
    die("Query gagal: " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../css/styles12.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
          .dashboard-summary {
            display: flex;
            gap: 20px;
            margin-top: 2px;
            flex-wrap: wrap; /* Agar item dapat menyesuaikan ukuran layar */
        }

        .summary-item {
            flex: 1;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            color: #fff;
            transition: transform 0.3s ease;
        }

        .summary-item:hover {
            transform: translateY(-5px);
        }

        .summary-item h3 {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .summary-item p {
            font-size: 2rem;
            margin: 0;
        }

        .summary-item i {
            font-size: 3rem;
            display: block;
            margin-bottom: 10px;
        }

        .summary-item-pasien {
            background-color: #3498db; /* Biru */
        }

        .summary-item-dokter {
            background-color: #2ecc71; /* Hijau */
        }

        .summary-item-kunjungan {
            background-color: #e74c3c; /* Merah */
        }

        .summary-item-ruangan {
            background-color: #f39c12; /* Oranye */
        }

        .summary-item-rekam-medis {
            background-color: #9b59b6; /* Ungu */
        }

        /* Icon style */
        .summary-item-pasien i {
            color: #fff;
        }

        .summary-item-dokter i {
            color: #fff;
        }

        .summary-item-kunjungan i {
            color: #fff;
        }

        .summary-item-ruangan i {
            color: #fff;
        }

        .summary-item-rekam-medis i {
            color: #fff;
        }
    </style>
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Admin Panel</h1>
            </div>
            <ul class="sidebar-list">
                <li class="sidebar-item">
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="sidebar-item">
                    <a href="view_users.php">Kelola Pasien</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_rekam_medis.php">Kelola Rekam Medis</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_dokter.php">Data Dokter</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_ruang.php">Ruang</a>
                </li>
                <li class="sidebar-item">
                    <a href="kelola_obat.php">Kelola Obat</a>
                </li>
                <li class="sidebar-item">
                    <a href="laporan.php">Laporan</a>
                </li>
            </ul>
        </aside>

        <main class="app-content">
            <header class="app-content-header">
                <div class="header-left">
                    <h2>Selamat datang, <?php echo htmlspecialchars($_SESSION['username']); ?></h2>
                </div>
                <div class="header-right">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user fa-fw"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="profil.php">Profile</a></li>
                                <li><a class="dropdown-item" href="settings.php">Settings</a></li>
                                <li>
                                    <hr class="dropdown-divider" />
                                </li>
                                <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </header>
            <div class="app-content-body">
                <div class="dashboard-summary">
                    <div class="summary-item summary-item-pasien">
                        <i class="fas fa-user-injured"></i>
                        <h3>Total Pasien</h3>
                        <p><?php echo $total_pasien; ?></p>
                    </div>
                    <div class="summary-item summary-item-dokter">
                        <i class="fas fa-user-md"></i>
                        <h3>Total Dokter</h3>
                        <p><?php echo $total_dokter; ?></p>
                    </div>
                    <div class="summary-item summary-item-kunjungan">
                        <i class="fas fa-calendar-day"></i>
                        <h3>Kunjungan Hari Ini</h3>
                        <p><?php echo $kunjungan_hari_ini; ?></p>
                    </div>
                    <div class="summary-item summary-item-ruangan">
                        <i class="fas fa-hospital"></i>
                        <h3>Ruangan Tersedia</h3>
                        <p><?php echo $total_ruangan; ?></p>
                    </div>
                    <div class="summary-item summary-item-rekam-medis">
                        <i class="fas fa-file-medical"></i>
                        <h3>Rekam Medis</h3>
                        <p><?php echo $total_rekam_medis; ?></p>
                    </div>
                </div>
            </div>
        </main>
    </div>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
