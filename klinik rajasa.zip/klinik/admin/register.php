<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="../css/styles2.css"> <!-- Ganti dengan path CSS Anda -->
</head>
<body>
    <div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    <form action="proses_register.php" method="post">
        <h2>Register Pengguna</h2>
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <label for="role">Role:</label>
        <select id="role" name="role" required>
            <option value="Admin">Admin</option>
            <option value="Dokter">Dokter</option>
            <option value="Pasien">Pasien</option>
        </select><br><br>

        <input type="submit" value="Register">
        <p>Sudah punya akun? <a href="login.php">Login disini</a></p>
    </form>
</body>
</html>
