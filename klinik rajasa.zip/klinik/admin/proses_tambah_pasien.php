<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran "Admin"
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Ambil data dari form
$nama_pasien = $_POST['nama_pasien'];
$alamat = $_POST['alamat'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$nomor_telepon = $_POST['nomor_telepon'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$golongan_darah = $_POST['golongan_darah'];
$status_pernikahan = $_POST['status_pernikahan'];
$jenis_pembayaran = $_POST['jenis_pembayaran'];
$tanggal_register = date("Y-m-d");

// Validasi data
if (empty($nama_pasien) || empty($alamat) || empty($tanggal_lahir) || empty($nomor_telepon) || empty($jenis_kelamin) || empty($golongan_darah) || empty($status_pernikahan) || empty($jenis_pembayaran)) {
    echo "Semua field harus diisi.";
    exit();
}

// Masukkan data ke database
$sql = "INSERT INTO pasien (nama_pasien, alamat, tanggal_lahir, nomor_telepon, jenis_kelamin, golongan_darah, status_pernikahan, jenis_pembayaran, tanggal_register) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssssss", $nama_pasien, $alamat, $tanggal_lahir, $nomor_telepon, $jenis_kelamin, $golongan_darah, $status_pernikahan, $jenis_pembayaran, $tanggal_register);

if ($stmt->execute()) {
    // Redirect setelah berhasil
    header("Location: view_users.php");
    exit();
} else {
    echo "Terjadi kesalahan: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
